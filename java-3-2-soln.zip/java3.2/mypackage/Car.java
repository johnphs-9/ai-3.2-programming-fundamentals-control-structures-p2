package mypackage;

public class Car {

    private void startAircon()
    {
        System.out.println("Aircon Started");
    }

    private void startRadio()
    {
        System.out.println(" Radio Started");

    }

    private void checkSeatBelts()
    {
      System.out.println("Seat belts checked ");
    }

    public void startEngine()
    {
        System.out.println("Starting engine...");
        System.out.println("Engine started...");
        startAircon();
        startAircon();
        checkSeatBelts();
    }

    
}
