public class TrafficLightDemo {
    public static void main(String[] args) {
        TrafficLight light = TrafficLight.RED;
        Direction d =Direction.W;

        // if(light == TrafficLight.RED)
        // {
        //     System.out.println("Stop");
        // }
        // else if(light == TrafficLight.YELLOW)
        // {
        //     System.out.println("Get Ready");
        // }
        // else if (light == TrafficLight.GREEN)
        // {
        //     System.out.println("Go");
        // }
       
        switch(d)
        {
            case N -> System.out.println("North");
            case E ->System.out.println("East");
            case W -> System.out.println("West");
            case S -> System.out.println("South");
        }

    }
}

enum TrafficLight { RED,YELLOW,GREEN}
