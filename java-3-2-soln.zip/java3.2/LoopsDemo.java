import java.util.Arrays;

public class LoopsDemo {
    public static void main(String[] args) {

        // // enhanced for-each loop

        int[] scores = { 85, 92, 78 };

        // for (int score : scores) {

        // System.out.println(score);
        // }

        // // Iteration using streams
        // //Hand each element to a stream, then print it

        // Arrays.stream(scores).forEach(score -> System.out.println(score));

        // Activity Solution- Grade the score
        // for(int score : scores )
        // {
        // String result = (score >= 50)? "Pass" : "Fail";

        // System.out.println(score + " -> " + result);
        // }

        // Continue and Break Statements
        int[] amounts = {50,120,-5,300,2000,80};
        for(int amount :amounts)
        {
            if(amount <= 0)// skip invalid entry
            continue;
            if(amount >1000)
                break;
            System.out.println("Processing "+amount);
        }


    }
}
