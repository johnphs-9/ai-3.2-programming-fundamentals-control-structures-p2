

enum Position{STAFF ,MANAGER, CEO}
public class BonusCalculator {

    //1. Salalry only - applies a standard 10% bonus

    public static double calcBonus(double salary)
    {
        return salary* 0.1;
    }

    // 2: Salary + custome rate

    public static double calcBonus(double salary , double rate)
    {
        return salary * rate;
    }

    public static double calcBonus(double salary , Position position)
    {
       return switch(position)
        {
            case STAFF -> salary * 0.1;
            case MANAGER -> salary * 0.2;
            case CEO -> salary *3.0;
            
        };
    }

    
    
}

