
/*
Create a `VendingMachine` class with an overloaded `makePayment` method:
- One version takes a `double` amount (cash) and prints that payment was accepted.
- One version takes an `EPayment` enum and calls a corresponding private method 
(`connectPayNow()`, `connectGrabPay()`, `connectFavePay()`), 
each returning `true`/`false` to simulate payment status.

```java
VendingMachine myVendingMachine = new VendingMachine();
myVendingMachine.makePayment(10.0);
myVendingMachine.makePayment(EPayment.GRABPAY);
myVendingMachine.makePayment(EPayment.FAVEPAY);
myVendingMachine.makePayment(EPayment.PAYNOW);
```

---
*/
enum EPayment {
    PAYNOW, GRABPAY, FAVEPAY
}

public class VendingMachine {

    public void makePayment(double amount) {
        System.out.println("Payment of $ " + amount + " accepted(cash). ");
    }

    public void makePayment(EPayment paymentType) {

        boolean success = switch(paymentType)
        {
            case PAYNOW -> connectPayNow();
            case GRABPAY -> connectGrabPay();
            case FAVEPAY ->connectFavePay();
        };

        if(success)
        {
            System.out.println(paymentType + " payment accepted ");
        }
        else 
        {
            System.out.println(" payment failed ");
        }

    }

    private boolean connectPayNow() {
        System.out.println("Connecting to PayNow...");
        return true;
    }

    private boolean connectGrabPay() {
        System.out.println("Connecting to GrabPay... ");
        return true;
    }

    private boolean connectFavePay()
    {
        System.out.println("Connecting to FavePay....");
        return true;
    }


    public static void main(String[] args) {
        
        VendingMachine myVendingMachine = new VendingMachine();
       // myVendingMachine.makePayment(10.0);
       // myVendingMachine.makePayment(EPayment.PAYNOW);

       myVendingMachine.makePayment(EPayment.GRABPAY);
    }
}
