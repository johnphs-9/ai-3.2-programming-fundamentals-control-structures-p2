
enum OrderStatus  { PENDING , SHIPPED,DELIVERED,CANCELLED}

public class OrderDemo {
    public static void main(String[] args) {
        
        OrderStatus status =OrderStatus.SHIPPED;

        System.out.println("Current Status: "+ status);

        // Enums compare safely with ==
        if(status == OrderStatus.SHIPPED)
        {
            System.out.println("Your order is on the way! ");
        }

        // Enums have a few built in helper
        System.out.println("Position in the list: "+ status.ordinal());
        System.out.println("As text: " + status.name());

        // value() returns every contant in the enum
        for(OrderStatus s :OrderStatus.values())
        {
            System.out.println(s);
        }
    }
    
}
