

public class App {

    public static void main(String[] args) {
        // Car car = new Car();
        // car.startEngine();

       // System.out.println(BonusCalculator.calcBonus(5000, 0.2));

        VendingMachine myVendingMachine = new VendingMachine();
        myVendingMachine.makePayment(10.0);
        myVendingMachine.makePayment(EPayment.PAYNOW);
    }
    
}
