public class EnumDemo {
    public static void main(String[] args) {
        
        // variable of enum Direction type
        Direction dir = Direction.E;
        System.out.println("Direction: " + dir);
    }
}

