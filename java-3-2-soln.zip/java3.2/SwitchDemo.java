public class SwitchDemo {

    public static void main(String[] args) {

        // enhanced switch
        // String direction ="E";

        // switch(direction)
        // {
        // case "N", "E","W","S" -> System.out.println("Valid Direction");

        // default -> System.out.println("Invalid input");
        // }

        // int rating = 5;

        // String feedback = switch (rating) {
        //     case 1, 2, 3 -> "Poor";
        //     case 4 -> "Good";
        //     case 5 -> "Excellent";
        //     default -> {
        //         yield "Invalid rating: " + rating;
        //     }
        // };
        // System.out.println(feedback);

        String result = describe("Alex");
        System.out.println(result);
        

    }

    //Pattern matching with switch

    static String describe(Object obj)
        {
            return switch(obj)
            {
                case Integer i when i < 0 -> "Negative number "+ i;
                case Integer i when i == 0-> "Zero";
                case String s -> "String " + s.toUpperCase();
                case null -> "null";
                default -> "Unknown Type";
            };

        }

}
